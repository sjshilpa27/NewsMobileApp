package com.web.newsapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.web.newsapp.ui.home.Adapter_home;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DetailView extends AppCompatActivity {
    String id;
    RequestQueue queue;
    TextView title, date, sectionid,desc;
    ImageView img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_detail_view);
        title = findViewById(R.id.title_detail);
        date = findViewById(R.id.date_detail);
        sectionid = findViewById(R.id.sectionid_detail);
        desc = findViewById(R.id.desc_detail);
        img = findViewById(R.id.img_detail);

//        ActionBar actionBar = getSupportActionBar();
//        if(actionBar != null) {
//            actionBar.setHomeButtonEnabled(true);
//            actionBar.setDisplayHomeAsUpEnabled(true);
//
//        }
//        Glide.with(this).load("https://www.csci571.com/hw/hw9/images/android/bluetwitter.png").into((ImageView) findViewById(R.id.twittericon));
        queue = Volley.newRequestQueue(this);
        getIncomingIntent();
        getDetail();

    }
//    public boolean onCreateOptionsMenu(Menu menu) {
////        getMenuInflater().inflate(R.menu.menu_detail,menu);
////
////        MenuItem item_bm = menu.findItem(R.id.bm);
////        MenuItem item_twitter = menu.findItem(R.id.twitter);
////
////        ImageView iv1 = new ImageView(this);
////        iv1.setMaxHeight(18);
////        iv1.setMaxWidth(18);
////        iv1.setImageResource(R.drawable.ic_bookmark_border_24dp);
////        //iv1.setImageURI(https://csci571.com/hw/hw9/images/android/bluetwitter.png);
////        item_bm.setActionView(iv1);
////
////        ImageView iv2 = new ImageView(this);
////        iv2.setMaxHeight(8);
////        iv2.setMaxWidth(8);
////        iv2.setPadding(0,0,0,0);
//
//
//        //iv1.setImageURI(https://csci571.com/hw/hw9/images/android/bluetwitter.png);
////        item_twitter.setActionView(iv2);
////        ActionBar actionBar = getSupportActionBar();
////        iv1.setScaleType(ImageView.ScaleType.CENTER);
////        ActionBar.LayoutParams layoutParams = new ActionBar.LayoutParams(
////                ActionBar.LayoutParams.WRAP_CONTENT,
////                ActionBar.LayoutParams.WRAP_CONTENT, Gravity.RIGHT
////                | Gravity.CENTER_VERTICAL);
////        layoutParams.rightMargin = 40;
////        iv1.setLayoutParams(layoutParams);
////        actionBar.setCustomView(iv1);
////        ActionBar.LayoutParams layoutParams = new ActionBar.LayoutParams(
////                ActionBar.LayoutParams.WRAP_CONTENT,
////                ActionBar.LayoutParams.WRAP_CONTENT, Gravity.RIGHT
////                | Gravity.CENTER_VERTICAL);
////        layoutParams.rightMargin = 40;
////        iv2.setLayoutParams(layoutParams);
////        getActionBar().setCustomView(iv2);
//
////        ActionBar actionBar = getSupportActionBar();
////        actionBar.setDisplayShowCustomEnabled(true);
////
////        LayoutInflater inflator = (LayoutInflater) this .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
////        View v = inflator.inflate(R.layout.actionbar_detail, null);
////
////        actionBar.setCustomView(v);
////
////        return true;
//    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void getIncomingIntent(){
        if(getIntent().hasExtra("id")){
            id = getIntent().getStringExtra("id");
            Toast.makeText(this,id,Toast.LENGTH_SHORT).show();
        }
    }


    private void getDetail() {
//        RequestQueue q = Volley.newRequestQueue(getContext());
        String url = "http://10.0.2.2:8081/detail_mobile/guardian?id="+id;

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        Log.i("resp",response.toString());
                        //Toast.makeText(getContext(),response.toString(),Toast.LENGTH_SHORT).show();
//                        t.setText(response.toString());
                        try {
                            title.setText(response.getString("title"));
                            desc.setText(response.getString("desc"));
                            date.setText(response.getString("date"));
                            sectionid.setText(response.getString("sectionid"));
                            Glide.with(getApplicationContext()).load(response.getString("img")).into(img);
                            setTitle(title.getText());

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("error",error.toString());

                    }
                });

// Access the RequestQueue through your singleton class.
        queue.add(jsonObjectRequest);


    }













//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        switch (item.getItemId()) {
//            case android.R.id.home:
//                // app icon in action bar clicked; goto parent activity.
//                this.finish();
//                return true;
//            default:
//                return super.onOptionsItemSelected(item);
//        }
//  }
}
