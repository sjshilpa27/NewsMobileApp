package com.web.newsapp;

public class News {
    //title,sectionid,date,img; desc,url;
    private String title, sectionid, date, img, desc, url;

    News(String title, String sectionid, String date, String img,String desc, String url){
        this.title = title;
        this.sectionid = sectionid;
        this.date = date;
        this.img = img;
        this.desc = desc;
        this.url = url;

    }


}
