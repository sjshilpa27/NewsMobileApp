package com.web.newsapp.ui.headlines;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.web.newsapp.R;
import com.web.newsapp.ui.home.Adapter_home;

import org.json.JSONArray;

public class World extends Fragment {
    RequestQueue queue;
    RecyclerView r1;
    Adapter_home adapter_home;
    // Required empty public constructor
    public World() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_world, container, false);
        r1= root.findViewById(R.id.rv_world);
        r1.setLayoutManager(new LinearLayoutManager(getContext()));
        //Toast.makeText(getContext(),"business",Toast.LENGTH_SHORT).show();
        queue = Volley.newRequestQueue(getContext());
        getWorld();

        return root;

    }
    private void getWorld() {
//        RequestQueue q = Volley.newRequestQueue(getContext());
        String url = "http://10.0.2.2:8081/topstories/guardian/world";

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONArray>() {

                    @Override
                    public void onResponse(JSONArray response) {
                        Log.i("resp",response.toString());
                        //Toast.makeText(getContext(),response.toString(),Toast.LENGTH_SHORT).show();
//                        t.setText(response.toString());
                        adapter_home = new Adapter_home(getContext(),response);
                        r1.setAdapter(adapter_home);
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("error",error.toString());

                    }
                });

// Access the RequestQueue through your singleton class.
        queue.add(jsonArrayRequest);


    }




}
