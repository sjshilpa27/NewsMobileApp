package com.web.newsapp.ui.home;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.web.newsapp.DetailView;
import com.web.newsapp.R;

import org.json.JSONArray;
import org.json.JSONException;

public class Adapter_home extends RecyclerView.Adapter<Adapter_home.Holder_home> {
    private JSONArray data;
    private Context context;
    private Holder_home holder;
    private int position;

    public Adapter_home(Context context, JSONArray data){
        this.data = data;
        this.context = context;
        //Log.i("A",Integer.toString(data.size()));
    }
    @NonNull
    @Override
    public Holder_home onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View card = LayoutInflater.from(parent.getContext()).inflate(R.layout.news_card, parent, false);
        Holder_home h = new Holder_home(card);
        return h;
        //return null;
    }

    @Override
    public void onBindViewHolder(@NonNull Holder_home holder, int position) {
        this.holder = holder;
        this.position = position;
        try {
            holder.title.setText(this.data.getJSONObject(position).getString("title"));
            holder.date.setText(this.data.getJSONObject(position).getString("date"));
            holder.id =this.data.getJSONObject(position).getString("id");
            holder.sectionid.setText(this.data.getJSONObject(position).getString("sectionid"));
            Glide.with(context).load(this.data.getJSONObject(position).getString("img")).into(holder.img);;



        } catch (JSONException e) {
            e.printStackTrace();
        }
        //holder.sectionid.setText(this.data.get(position).age);


        //holder.image.setImageResource(this.data.get(position).photoId);
    }

    @Override
    public int getItemCount() {
        return this.data.length();
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }

    public class Holder_home extends RecyclerView.ViewHolder {
        private TextView title;
        private TextView date;
        private TextView url;
        private TextView sectionid;
        private  ImageView img;
        private CardView card;
        private String id;

        public Holder_home(@NonNull View view) {
            super(view);
            card = view.findViewById(R.id.cv);
            title = card.findViewById(R.id.title_detail);
            date = card.findViewById(R.id.date_detail);
            img = card.findViewById(R.id.img);
            sectionid = card.findViewById(R.id.sectionid_detail);
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.d("CARD",id);
//                    Toast.makeText(context,id,Toast.LENGTH_SHORT).show();
                    Intent detail = new Intent(context, DetailView.class);
                    detail.putExtra("id",id);
                    context.startActivity(detail);
                }
            });
        }
    }
}
