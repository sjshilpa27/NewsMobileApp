package com.web.newsapp.ui.home;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.web.newsapp.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class HomeFragment extends Fragment implements LocationListener {
    RequestQueue queue;
    private HomeViewModel homeViewModel;
    RecyclerView r1;
    Adapter_home adapter;
    private JSONArray news;
    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    LocationManager locationManager;
    String provider;
    ProgressDialog progressDialog;
    TextView city_weather,temp_weather,state_weather,desc_weather;
    ImageView img_weather;

    public boolean checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(getContext(),
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                    Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new AlertDialog.Builder(getContext())
                        .setTitle(R.string.title_location_permission)
                        .setMessage(R.string.text_location_permission)
                        .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(getActivity(),
                                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                        MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        })
                        .create()
                        .show();


            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
            return false;
        } else {
            return true;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // location-related task you need to do.
                    if (ContextCompat.checkSelfPermission(getContext(),
                            Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {

                        //Request location updates:
                        locationManager.requestLocationUpdates(provider, 400, 1, this);
                    }

                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.

                }
                return;
            }

        }
    }



    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        r1 = root.findViewById(R.id.rv_home);
        r1.setLayoutManager(new LinearLayoutManager(getContext()));
        city_weather = root.findViewById(R.id.city_weather);
        state_weather = root.findViewById(R.id.state_weather);
        temp_weather = root.findViewById(R.id.temp_weather);
        desc_weather = root.findViewById(R.id.desc_weather);
        img_weather = root.findViewById(R.id.img_weather);



        //final TextView textView = root.findViewById(R.id.text_home);
//        homeViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
//            @Override
//            public void onChanged(@Nullable String s) {
//                textView.setText(s);
//            }
//        });
        //Weather
        queue = Volley.newRequestQueue(getContext());
        getWeather();
        getHomeData();
        r1.setNestedScrollingEnabled(false);
        return root;
    }

    private void getHomeData() {
//        RequestQueue q = Volley.newRequestQueue(getContext());
        String url = "http://10.0.2.2:8081/headlines";

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONArray>() {

                    @Override
                    public void onResponse(JSONArray response) {
                        Log.i("resp", response.toString());
//                        Toast.makeText(getContext(), response.toString(), Toast.LENGTH_SHORT).show();
                        adapter = new Adapter_home(getContext() ,response);
                        r1.setAdapter(adapter);
                        progressDialog.dismiss();
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("error",error.toString());

                    }
                });

// Access the RequestQueue through your singleton class.
        queue.add(jsonArrayRequest);
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Loading");
        progressDialog.show();

    }

    public void getWeather(){
        checkLocationPermission();
        //Latitude, Longitude
        locationManager = (LocationManager)getContext().getSystemService(getContext().LOCATION_SERVICE);
        Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        double longitude = location.getLongitude();
        double latitude = location.getLatitude();
        Geocoder geocoder = new Geocoder(getContext(), Locale.getDefault());
        List<Address> addresses = null;
        try {
            addresses = geocoder.getFromLocation(latitude, longitude, 1);
        } catch (IOException e) {
            e.printStackTrace();
        }
        Log.i("Add",addresses.toString());
        String cityName = addresses.get(0).getLocality();
        String stateName = addresses.get(0).getAdminArea();
        city_weather.setText(cityName);
        state_weather.setText(stateName);
//        Log.i("city",cityName);
//        Log.i("state",stateName);

        //Weather API Call
        String url = "https://api.openweathermap.org/data/2.5/weather?q="+cityName+"&units=metric&appid=20b2d4869df3b22feb4fff95c7b75e30";

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        try{
//                          textView.setText("Response: " + response.toString());
                            Log.i("response", response.toString());
                            JSONObject main = null;
                            JSONArray weather = null;
                            JSONObject weather_0 = null;
                            double temp = 0;
                            String desc = "";
//                            Log.i("xyz","xyz");
                            main = (JSONObject) response.get("main");
                            Log.i("main",main.toString());
                            weather = (JSONArray) response.get("weather");
                            Log.i("weather",weather.toString());
                            weather_0 = (JSONObject) weather.get(0);
                            temp = main.getDouble("temp");
                            desc = weather_0.getString("main");
                            temp_weather.setText(Integer.toString((int)Math.round(temp))+" \u2103");
                            desc_weather.setText(desc);

                            switch (desc){

                                case "Clouds":
                                    Glide.with(getContext()).load("https://csci571.com/hw/hw9/images/android/cloudy_weather.jpg").into(img_weather);;
                                    break;
                                case "Clear":
                                    Glide.with(getContext()).load("https://csci571.com/hw/hw9/images/android/clear_weather.jpg").into(img_weather);;
                                    break;
                                case "Snow":
                                    Glide.with(getContext()).load("https://csci571.com/hw/hw9/images/android/snowy_weather.jpg").into(img_weather);;
                                    break;
                                case "Rain":
                                    Glide.with(getContext()).load("https://csci571.com/hw/hw9/images/android/rainy_weather.jpg").into(img_weather);;
                                    break;
                                case "Drizzle":
                                    Glide.with(getContext()).load("https://csci571.com/hw/hw9/images/android/rainy_weather.jpg").into(img_weather);;
                                    break;
                                case "Thunderstorm":
                                    Glide.with(getContext()).load("https://csci571.com/hw/hw9/images/android/thunder_weather.jpg").into(img_weather);;
                                    break;
                                default:
                                    Glide.with(getContext()).load("https://csci571.com/hw/hw9/images/android/sunny_weather.jpg").into(img_weather);;
                                    break;


                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO: Handle error

                    }
                });

// Access the RequestQueue through your singleton class.
        queue.add(jsonObjectRequest);

    }

    @Override
    public void onLocationChanged(Location location) {
        Double lat = location.getLatitude();
        Double lng = location.getLongitude();

        Log.i("Location info: Lat", lat.toString());
        Log.i("Location info: Lng", lng.toString());
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
}

